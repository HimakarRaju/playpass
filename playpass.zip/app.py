from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from functools import wraps
import pandas as pd
import os
import plotly.express as px
import plotly.io as pio
import json

from recommender import generate_recommendations, should_trigger_recommender, get_cached_recommendations, RECOMMENDER_CACHE_PATH


# Flask app config
app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///play_members.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'

db = SQLAlchemy(app)

# Global
DATA_FILE = "Data/play_data.xlsx"
EXPECTED_COLUMNS = [
    'ID', 'Name', 'Email', 'Phone', 'Age', 'Gender', 'Income Level', 'Device Type', 'Android Version',
    'App Name', 'Developer', 'Category', 'Sub_Category', 'Free/Paid', 'In-App Purchases',
    'App Size (MB)', 'Total Installs', 'Transaction ID', 'Transaction Type', 'App/Game Price',
    'Discount Applied', 'Promo Code Used', 'Price Paid (with Coupon)', 'Amount Spent on In-App Purchases',
    'Time Spent (min)', 'Session Count', 'Time Since Last Use (days)', 'Favorite Flag', 'Uninstalled',
    'Date', 'Time', 'Day of Week', 'Weekend', 'Season', 'Rating', 'Review Text', 'Review Sentiment',
    'Review Length', 'Demographic Location', 'State', 'Country', 'Region', 'Play Pass User',
    'Subscription Duration', 'Auto-Renew', 'App Tags', 'Age Rating', 'Device Locale/Language'
]


# User Model
class PlayMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(255))
    is_admin = db.Column(db.Boolean, default=False)

# Helper Functions


def save_charts_to_disk(charts, filepath='chart_cache.json'):
    with open(filepath, 'w') as f:
        json.dump(charts, f)

def load_charts_from_disk(filepath='chart_cache.json'):
    if os.path.exists(filepath):
        with open(filepath, 'r') as f:
            return json.load(f)
    return None

# Login required decorator
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            flash("Login required", "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper

# Routes

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        is_admin = True if request.form.get('admin') == 'on' else False

        if PlayMember.query.filter_by(username=username).first():
            flash("Username already exists", "danger")
            return redirect(url_for('register'))

        new_user = PlayMember(username=username, password=password, is_admin=is_admin)
        db.session.add(new_user)
        db.session.commit()
        flash("User registered!", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = PlayMember.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['is_admin'] = user.is_admin
            return redirect(url_for('dashboard'))
        flash("Invalid credentials", "danger")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out", "info")
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    username = PlayMember.query.get(session['user_id']).username
    return render_template('dashboard.html' , username=username)

@app.route('/get_charts', methods=['GET'])
@login_required
def get_charts():
    # Try load cached first
    if request.args.get('refresh') != 'true':
        cached = load_charts_from_disk()
        if cached:
            return jsonify(cached)

    try:
        df = pd.read_excel(DATA_FILE)
        if list(df.columns) != EXPECTED_COLUMNS:
            return jsonify({'error': 'Dataset structure mismatch'})

        cat_data = df['Category'].value_counts().nlargest(10).reset_index()
        cat_data.columns = ['Category', 'count']

        cat_fig = px.bar(cat_data, x='Category', y='count', title='Top 10 Categories')
        play_fig = px.pie(df, names='Play Pass User', title='Play Pass Breakdown')
        inapp_fig = px.bar(df.groupby('Category')['Amount Spent on In-App Purchases'].mean().reset_index(),
                           x='Category', y='Amount Spent on In-App Purchases', title='Avg In-App Purchase')
        rating_fig = px.histogram(df, x='Rating', title='Ratings')

        charts = {
            'cat_chart': pio.to_json(cat_fig),
            'play_chart': pio.to_json(play_fig),
            'inapp_chart': pio.to_json(inapp_fig),
            'rating_chart': pio.to_json(rating_fig),
        }

        save_charts_to_disk(charts)
        return jsonify(charts)

    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return jsonify({'error': str(e)})


@app.route('/upload', methods=['POST'])
@login_required
def upload():
    file = request.files.get('file')
    if not file:
        flash("No file uploaded", "warning")
        return redirect(url_for('dashboard'))

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    try:
        df = pd.read_excel(filepath)
        if list(df.columns) != EXPECTED_COLUMNS:
            flash("Uploaded file structure doesn't match expected dataset.", "danger")
        else:
            df.to_excel(DATA_FILE, index=False)
            flash("Dataset updated!", "success")
    except Exception as e:
        flash(f"Error processing file: {e}", "danger")

    return redirect(url_for('dashboard'))

@app.route("/run_recommender", methods=["POST"])
@login_required
def run_recommender():
    try:
        recs_df = generate_recommendations()
        # Update row count in cache
        recs_df.attrs["row_count"] = pd.read_excel(DATA_FILE).shape[0]
        recs_df.to_pickle(RECOMMENDER_CACHE_PATH)
        return jsonify({"status": "success", "message": f"{len(recs_df)} recommendations generated."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route("/recommendations")
@login_required
def recommendations():
    recs = get_cached_recommendations()

    if recs.empty:
        return "No recommendations yet. Run the recommender first."

    # Load the full dataset for chart data
    full_df = pd.read_excel(DATA_FILE)

    # Age group aggregation
    def age_group(age):
        if age < 18:
            return 'Under 18'
        elif age < 25:
            return '18-24'
        elif age < 35:
            return '25-34'
        elif age < 50:
            return '35-49'
        else:
            return '50+'

    full_df["Age Group"] = full_df["Age"].apply(age_group)
    age_data = full_df["Age Group"].value_counts().sort_index().to_dict()

    # Region aggregation
    region_data = full_df["Region"].value_counts().to_dict()

    # Category aggregation
    category_data = full_df["Category"].value_counts().to_dict()

    # Subscription Duration aggregation
    duration_data = full_df["Subscription Duration"].value_counts().sort_index().to_dict()

    # Price histogram data
    price_data = full_df["Price Paid (with Coupon)"].dropna().tolist()

    pass_data = full_df["Play Pass User"].value_counts().to_dict()
    pass_data = {k: v for k, v in pass_data.items() if k != 'N/A'}

    table_html = recs.to_html(index=False, classes="table table-striped")

    return render_template(
        "recommendations.html",
        table_html=table_html,
        recommendations=recs.to_dict(orient="records"),
        age_data=age_data,
        region_data=region_data,
        category_data=category_data,
        duration_data=duration_data,
        price_data=price_data,
        pass_data=pass_data,
    )



# this is to trigger the recommender automatically when the dashboard is accessed
# @app.before_request
# def auto_trigger_check():
#     if request.endpoint == "dashboard" and should_trigger_recommender():
#         try:
#             generate_recommendations()
#         except:
#             pass  # Fail silently


# Init
if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    with app.app_context():
        db.create_all()
    app.run(debug=True)
